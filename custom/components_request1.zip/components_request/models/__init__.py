"""init models"""
# -*- coding: utf-8 -*-
from . import component_request
from . import components_product
