# -*- coding: utf-8 -*-
from . import product_purchase_order
