# -*- coding: utf-8 -*-
from . import survey_survey
from . import contact_relation
from . import res_partner
