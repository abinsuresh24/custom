# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ResUsers(models.Model):
    _inherit = 'res.partner'
    _description = "Inherited res partner"

    customer_order_ids = fields.One2many('customer.order', 'cus_order_id',
                                         string="Customer orders")
    cust_order = fields.Boolean(string="Customer order")
    product_count = fields.Char(string="products")

    @api.onchange('cust_order')
    def _onchange_cus_order(self):
        orders = self.env['sale.order'].search([('partner_id', '=', self.name)])
        product = self.env['sale.order.line'].search_count(
            [('id', '=', orders.id)])
        self.product_count = product
        for rec in orders:
            self.customer_order_ids = [
                (0, 0, {'order_details': rec.name})]

    def action_order_products(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'ordered_product',
            'view_mode': 'tree',
            'res_model': 'sale.order',
            'domain': [('partner_id', '=', self.name)],
            'context': {'create': False}
        }
