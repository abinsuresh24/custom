# -*- coding: utf-8 -*-
from . import customer_order
from . import res_partners
