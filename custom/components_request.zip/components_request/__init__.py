"""Init components request"""
# -*- coding: utf-8 -*-
from . import models
