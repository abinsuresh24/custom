# -*- coding: utf-8 -*-
from odoo import fields, models


class EventEvent(models.Model):
    _inherit = 'event.event'

    image = fields.Image(string="Event image")
