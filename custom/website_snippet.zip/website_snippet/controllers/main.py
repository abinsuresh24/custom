# -*- coding: utf-8 -*-
import json
from odoo import http
from odoo.http import request


class Sales(http.Controller):
    @http.route(['/latest_events'], type="json", auth="public")
    def latest_events(self):
        events = request.env['event.event'].sudo().search_read([], limit=4,
                                                        order='date_begin desc')
        return events
