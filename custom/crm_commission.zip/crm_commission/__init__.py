"""Init crm commission"""
# -*- coding: utf-8 -*-
from . import models
